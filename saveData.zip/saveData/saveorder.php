<?php

class Order {
	private function getConfig()
	{
		$config = array(
				"host"=> "localhost",
				"user" => "root",
				"pass" => ""
		);
	return $config;
	}
	
	private function connectDB()
	{
		$config = Order::getConfig();
		$con = mysql_connect($config['host'], $config['user'], $config['pass']) or die("not connected ");
	return $con;
	}
	
	public function GetAllOrder()
	{
	
		$db= Order::connectDB();

		$table ="order_table";
		mysql_select_db("orders",$db);

		$val = mysql_query("SELECT id, name,email,phone from  `orders`.`".$table."` ; " , $db) or die(" Not Done");
		
		//$returnArray  = array();
		
		while($row = mysql_fetch_object($val))
		{
				$returnArray[] = $row;
						
		}
		
		print_r(json_encode($returnArray));
		die();
		return json_encode($returnArray);
	
	}
	
	
	public function save_order($params)
	{
		$db= Order::connectDB();
	
		$table ="order_table";
		
		mysql_select_db("orders",$db);
		mysql_query("INSERT INTO  `orders`.`".$table."`  (`name`,`email`,`phone`) VALUES ( '".$params['name']."','".$params['email']."','".$params['phone']."'); " , $db) or die(" Not Done");
	
	return json_encode($params);
	}
	
	public function edit_Order($params)
	{
		$db= Order::connectDB();
	
		$table ="order_table";
		
		mysql_select_db("orders",$db);
		mysql_query("UPDATE `orders`.`".$table."` SET name='".$params['name']."',email='".$params['email']."', phone='".$params['phone']."' WHERE id = '".$params['id']."'") or die(" Update Failed!");
	
	return json_encode($params);
	}
	
	public function delete_Order($params)
	{
		$db= Order::connectDB();
	
		$table ="order_table";
		
		mysql_select_db("orders",$db);
		mysql_query("DELETE from `orders`.`".$table."` WHERE id = '".$params['id']."'") or die(" Delete not successful!");
	
	return json_encode($params);
	}
}

	if(isset($_GET['action'])) 
	{
	
		$action = $_GET['action'];
		switch ($action) {
			case "save" : 
				$orderObj = new Order();
				$return = $orderObj->save_order($_POST);
		
				echo $return;
			break;
			
			case "get_orders":
				$orderObj = new Order();
				$order =  $orderObj->GetAllOrder();
				
				echo json_encode($order);
			break;
			
			case "edit":
				$orderObj = new Order();
				$order =  $orderObj->edit_Order($_POST);
				
				echo json_encode($order);
			break;
			
			case "delete_order":
				$orderObj = new Order();
				$order =  $orderObj->delete_Order($_POST);
				
				echo json_encode($order);
			break;
	
		}
	}
?>