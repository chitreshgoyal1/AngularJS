-- phpMyAdmin SQL Dump
-- version 4.1.6
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jul 22, 2014 at 11:39 AM
-- Server version: 5.6.16
-- PHP Version: 5.5.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `orders`
--

-- --------------------------------------------------------

--
-- Table structure for table `order_table`
--

CREATE TABLE IF NOT EXISTS `order_table` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) NOT NULL,
  `email` varchar(250) NOT NULL,
  `phone` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=86 ;

--
-- Dumping data for table `order_table`
--

INSERT INTO `order_table` (`id`, `name`, `email`, `phone`) VALUES
(1, 'Rajiv Meena', 'rajiv@gmail.com', '8247596898'),
(2, 'Lalit', 'lalit@thepsi.com', '95865475'),
(3, 'Somil', 'somil@gmail.com', '9610283811'),
(4, 'chitresh', 'Chitresh@raj.com', '9610283444'),
(5, 'Umesh', 'mishra@gmail.com', '9874856121'),
(6, 'Ramesh', 'ramesh@gmail.com', '5478'),
(7, 'Suresh', 'Suresh@gmail.com', '7845451211'),
(8, 'Nisha', 'nisha@gmail.com', '124569'),
(9, 'raj', 'mishra', '8596777744'),
(10, 'Collector & DM', 'CollectorBohra@example.com', '9530312511'),
(11, 'Bachnesh Agrawal', 'BachneshAgrawal@gmail.com', '9530312506'),
(12, 'Tikam Chand Bohra', 'TikamChand@example.com', '9530312504'),
(13, 'Sukhveer Saini', 'SukhveerSaini@example.com', '9530312507'),
(14, 'Dr. Virendra Singh Meena', 'Dr.Virendra@example.com', '9530312501'),
(15, 'Pukhraj Sain', 'PukhrajSain@example.com', '9530312508'),
(16, 'Hanuman Mal Dhaka', 'HanumanMal@example.com', '9530312510'),
(17, 'Sushma Arora', 'SushmaArora@example.com', '9461246045'),
(18, 'Jyoti Chouhan', 'JyotiChouhan@example.com', '9530312513'),
(19, 'B.L. Yadav', 'B.L.Yadav@example.com', '9024991962'),
(20, 'Ikbal Hussain', 'IkbalHussain@example.com', '9530312512'),
(21, 'Purushottam Sharma', 'PurushottamSharma@example.com', '9530312509'),
(22, 'Dr. Ramavtar Gurjar', 'Dr.Ramavtar@example.com', '9530312503'),
(23, 'Vinod Agarwal', 'VinodAgarwal@example.com', '9414349244'),
(24, 'Namita Patel', 'NamitaPatel@example.com', '9530312505'),
(25, 'Seema Sharma', 'SeemaSharma@example.com', '9461309262'),
(26, 'Anupama Jorwal', 'AnupamaJorwal@example.com', '9414446342'),
(27, 'Paras Chand Jain', 'ParasChand@example.com', '9530300010'),
(28, 'Kanishak Saini', 'KanishakSaini@example.com', '9414102097'),
(29, 'Mahesh Narayan', 'MaheshNarayan@example.com', '7727883641'),
(30, 'Ashok Kumar', 'AshokKumar@example.com', '9530300012'),
(31, 'Birbal Singh', 'BirbalSingh@example.com', '9461626484'),
(32, 'Sawan Kumar Chayal', 'SawanKumar@example.com', '9928283197'),
(33, 'Sunil Punia', 'SunilPunia@example.com', '9314018833'),
(34, 'Mukesh Kayathwal', 'MukeshKayathwal@example.com', '9982638385'),
(35, 'Ashok Choudhary', 'AshokChoudhary@example.com', '9414139900'),
(36, 'Rajesh Nayak', 'RajeshNayak@example.com', '9414868111'),
(37, 'Radhey Pratap Singh', 'RadheyPratap@example.com', '9414322146'),
(38, 'B.K. Tiwari', 'B.K.Tiwari@example.com', '9783861145'),
(39, 'Ramratan Sharma', 'RamratanSharma@example.com', '9928012457'),
(40, 'B.L.Verma', 'B.L.VermaSingh@example.com', '9468695577'),
(41, 'Arvind Mohan', 'ArvindMohan@example.com', '9001644943'),
(42, 'Rameshwar Parsoya', 'RameshwarParsoya@example.com', '9772432233'),
(43, 'N.L.Sharma', 'N.L.SharmaKavia@example.com', '9529941009'),
(44, 'Satish Goyal', 'SatishGoyal@example.com', '9772432233'),
(45, 'Varun Mishra', 'VarunMishra@example.com', '9772432233'),
(46, 'Roop Singh Kavia', 'RoopSingh@example.com', '9772432233'),
(47, 'Rajendra Kumar Sharma', 'RajendraKumar@example.com', '9772432233'),
(48, 'Renu Bhatt', 'RenuBhatt@example.com', '9829600368'),
(49, 'Deshraj Meena', 'DeshrajMeena@example.com', '9829322033'),
(50, 'R.K. Meena', 'R.K.Meena@example.com', '9468683600'),
(51, 'Mo. Saleem Khan', 'Mo.Saleem@example.com', '9351538255'),
(52, 'Rajendra Singh', 'RajendraSingh@example.com', '9414012555'),
(53, 'Shefali Kushwah', 'ShefaliKushwah@example.com', '9414333498'),
(54, 'Ku. Santosh Meena', 'Ku.Santosh@example.com', '9414322654'),
(55, 'Vinod Purohit', 'VinodPurohit@example.com', '9414050487'),
(56, 'Rajeev Pandey', 'RajeevPandey@example.com', '8107444645'),
(57, 'Prabha Vyas', 'PrabhaVyas@example.com', '9829019178'),
(58, 'Chhotu Ram Bairwa', 'ChhotuRam@example.com', '9950356867'),
(59, 'Satyanarayan', 'SatyanarayanBairwa@example.com', '9414325943'),
(60, 'B.L. Meena', 'B.L.Meena@example.com', '9929597474'),
(61, 'Phool Chand', 'PhoolChand@example.com', '9829388383'),
(62, 'Jwar Singh Meena', 'JwarSingh@example.com', '9414033286'),
(63, 'Mohan Lal Bairwa', 'MohanLal@example.com', '9460331333'),
(64, 'Nandlal Bunkar', 'NandlalBunkar@example.com', '-'),
(65, 'Hazari Lal Nagar', 'HazariLal@example.com', '9530312485 978542378'),
(66, 'Jitendra Kumar Soni', 'JitendraKumar@example.com', '9829600225'),
(67, 'Mahaveer Singh', 'MahaveerSingh@example.com', '9414057400'),
(68, 'Ramavtar Meena (I)', 'RamavtarMeena@example.com', '9530312486 982935544'),
(69, 'Manmohan Meena', 'ManmohanMeena@example.com', '9828100813'),
(70, 'Ravi Vijay', 'RaviVijay@example.com', '9610777782'),
(71, 'Nand Kishore Tiwari', 'NandKishore@example.com', '7742754314'),
(72, 'Ashok Kumar Sharma', 'AshokKumar@example.com', '9829609540'),
(73, 'Laxmikant Katara', 'LaxmikantKatara@example.com', '9530312488 979939058'),
(74, 'Prabhudayal', 'PrabhudayalNayak@example.com', '9530312495 941477946'),
(75, 'Mubarak Husain', 'MubarakHusain@example.com', '9530312499 982869996'),
(76, 'Rakesh Chaudhary', 'RakeshChaudhary@example.com', '9530312489 941441714'),
(77, 'Kailash Chand Nayak', 'KailashChand@example.com', '9460205745 953031249'),
(78, 'Ranveer', 'RanveerYadav@example.com', '9530312498 982906302'),
(79, 'Beni Prasad Yadav', 'BeniPrasad@example.com', '9530312500, 98296004'),
(80, 'Rajendra Shekhawat', 'RajendraShekhawat@example.com', '9530312493 941447554'),
(81, 'Manish Kumar', 'ManishKumar@example.com', '9530312496'),
(82, 'Nidhi Shakeet', 'NidhiShakeet@example.com', '9530312491, 94140180'),
(83, 'Rais Ahamad', 'RaisAhamad@example.com', '9530312490, 94143676'),
(84, 'Krishnavtar Jaiman', 'KrishnavtarJaiman@example.com', '9530312497, 94142750'),
(85, 'Jagdish Meena', 'JagdishMeena@example.com', '9414009951');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
